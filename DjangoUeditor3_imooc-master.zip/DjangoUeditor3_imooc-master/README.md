# DjangoUeditor3_imooc
慕课网 vue2.x 和 django 打造生鲜超市的课程中兼容django ueditor兼容python2和python3
